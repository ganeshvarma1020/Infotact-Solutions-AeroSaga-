@echo off
echo ========================================================
echo   Starting AeroSaga React Frontend (Vite)
echo ========================================================
cd frontend
call npm.cmd run dev
pause
