# AeroSaga: Autonomous Drone Mission Control Platform

[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.3.4-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Temporal.io](https://img.shields.io/badge/Temporal.io%20SDK-1.25.1-blue.svg)](https://temporal.io/)
[![React](https://img.shields.io/badge/React-18-61DAFB.svg)](https://reactjs.org/)
[![Vite](https://img.shields.io/badge/Vite-latest-646CFF.svg)](https://vitejs.dev/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0-orange.svg)](https://www.mysql.com/)

AeroSaga is an enterprise-grade autonomous drone mission control and fleet management system orchestrated by **Temporal.io**, powered by **Spring Boot**, and interfaced via a **React** dashboard.

---

## 🏛️ System Architecture

```
                                  +---------------------------------------+
                                  |   Web Browser / Mission Control UI    |
                                  |   (React 18 / Vite / Recharts / JWT)  |
                                  +---------------------------------------+
                                                     |
                                            HTTP REST / Bearer JWT
                                                     v
                                  +---------------------------------------+
                                  |      Spring Boot API Gateway Layer    |
                                  |  - AuthController (/api/auth)         |
                                  |  - DroneController (/api/drones)      |
                                  |  - MissionController (/api/missions)  |
                                  |  - TelemetryController (/api/telemetry|
                                  +---------------------------------------+
                                                     |
                                                     v
                                  +---------------------------------------+
                                  |        Service & Business Layer       |
                                  |  - AuthService                        |
                                  |  - DroneFleetService                  |
                                  |  - MissionService                     |
                                  |  - TelemetryService                   |
                                  +---------------------------------------+
                                         /                         \
                                        v                           v
              +-----------------------------------+    +----------------------------+
              |     Temporal.io Workflow Engine   |    |      Spring Data JPA       |
              |-----------------------------------|    |----------------------------|
              | DroneMissionWorkflow (Orchestrator|    | MySQL 8.0: aerosaga_db     |
              |  - validateMission (Activity)     |    |  * users (RBAC & JWT)      |
              |  - reserveDrone (Activity)        |    |  * drones (Fleet assets)   |
              |  - simulateFlightStep (Activity)  |    |  * missions (Flight jobs)  |
              |  - finalizeMission (Activity)     |    |  * telemetry (Time series) |
              |  - compensateMissionFailure (Saga)|    |  * mission_events (Audits) |
              +-----------------------------------+    +----------------------------+
```

---

## ⚡ Temporal.io Workflow & The Saga Pattern

Autonomous drone missions are inherently **long-running**, **asynchronous**, and **safety-critical**.
- **Deterministic Orchestration**: `DroneMissionWorkflowImpl` executes deterministic stages:
  1. `validateMission`: Pre-flight avionics check, weather matrix, and coordinate validation.
  2. `reserveDrone`: Drone asset locking and battery health verification ($\ge 20\%$).
  3. `simulateFlightStep`: Iterative waypoint navigation with physics-based altitude/battery updates.
  4. `finalizeMission`: Safe landing, status marked as `COMPLETED`, drone released to `AVAILABLE`.
- **The Saga Pattern Compensation**:
  - Registered via `saga.addCompensation(activities::compensateMissionFailure, ...)`.
  - When an abort signal (`signalEmergencyAbort`) or unexpected fault occurs, `saga.compensate()` executes compensating rollback:
    - Marks mission as `FAILED`.
    - Resets drone asset safely to `AVAILABLE` (or `MAINTENANCE` if battery critical).
    - Logs emergency audit records to MySQL `mission_events`.

---

## 📡 REST API Reference

| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login` | Authenticate user and issue JWT Bearer token | Public |
| `POST` | `/api/auth/register` | Register new user (`ADMIN` or `OPERATOR`) | Public |
| `GET` | `/api/auth/me` | Fetch authenticated identity | Bearer JWT |
| `GET` | `/api/drones` | List all fleet assets | Bearer JWT |
| `GET` | `/api/drones/available` | List drones ready for mission dispatch | Bearer JWT |
| `POST` | `/api/missions` | Schedule a new flight mission | Bearer JWT |
| `POST` | `/api/missions/{id}/launch` | Dispatch mission into Temporal workflow engine | Bearer JWT |
| `POST` | `/api/missions/{id}/abort` | Dispatch emergency abort signal (triggers Saga compensation) | Bearer JWT |
| `GET` | `/api/missions/{id}/temporal-state`| Query live Temporal workflow execution phase | Bearer JWT |
| `GET` | `/api/telemetry/mission/{id}/latest`| Fetch latest telemetry snapshot for short-polling | Bearer JWT |

---

## 🚀 Running the Services

### 1. Spring Boot Backend (Port 8080)
Double-click `run-backend.bat` or run:
```powershell
cd backend
.\mvnw.cmd spring-boot:run
```
- Swagger OpenAPI: `http://localhost:8080/swagger-ui.html`

### 2. React Frontend (Port 5173)
Double-click `run-frontend.bat` or run:
```powershell
cd frontend
npm.cmd run dev
```
- Web Application: `http://localhost:5173`

### Default Logins
- Admin: `admin` / `admin123`
- Operator: `operator` / `operator123`
