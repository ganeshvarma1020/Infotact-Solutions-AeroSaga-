@echo off
echo ========================================================
echo   Starting AeroSaga Backend (Spring Boot + Temporal.io)
echo ========================================================
cd backend
.\mvnw.cmd spring-boot:run
pause
