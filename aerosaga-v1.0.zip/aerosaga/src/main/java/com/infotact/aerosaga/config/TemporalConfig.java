package com.infotact.aerosaga.config;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.infotact.aerosaga.workflow.MissionActivities;
import com.infotact.aerosaga.workflow.MissionWorkflowImpl;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;

/**
 * Two jobs:
 * 1. Connection: a client that talks to the Temporal server (start missions, send signals, run queries).
 * 2. Worker: a background loop that picks up mission tasks from the queue and runs our workflow
 *    and activity code. In this app the API and the worker live in the same process.
 */
@Configuration
public class TemporalConfig {

    private static final Logger log = LoggerFactory.getLogger(TemporalConfig.class);

    @Bean
    @ConditionalOnProperty(prefix = "aerosaga.temporal", name = "connect", havingValue = "true", matchIfMissing = true)
    WorkflowServiceStubs workflowServiceStubs(AeroSagaProperties props) {
        log.info("Temporal target: {}", props.temporal().target());
        return WorkflowServiceStubs.newServiceStubs(WorkflowServiceStubsOptions.newBuilder()
                .setTarget(props.temporal().target())
                .build());
    }

    @Bean
    @ConditionalOnProperty(prefix = "aerosaga.temporal", name = "connect", havingValue = "true", matchIfMissing = true)
    WorkflowClient workflowClient(WorkflowServiceStubs stubs, AeroSagaProperties props) {
        return WorkflowClient.newInstance(stubs, WorkflowClientOptions.newBuilder()
                .setNamespace(props.temporal().namespace())
                .build());
    }

    @Bean
    @ConditionalOnProperty(prefix = "aerosaga.temporal", name = "worker-enabled", havingValue = "true", matchIfMissing = true)
    WorkerFactory workerFactory(WorkflowClient client, MissionActivities activities, AeroSagaProperties props) {
        WorkerFactory factory = WorkerFactory.newInstance(client);
        Worker worker = factory.newWorker(props.temporal().taskQueue());
        worker.registerWorkflowImplementationTypes(MissionWorkflowImpl.class);
        worker.registerActivitiesImplementations(activities);
        return factory;
    }

    /** Starts the worker after the app is ready, and stops it cleanly on shutdown. */
    @Bean
    @ConditionalOnProperty(prefix = "aerosaga.temporal", name = "worker-enabled", havingValue = "true", matchIfMissing = true)
    SmartLifecycle temporalWorkerLifecycle(WorkerFactory factory, AeroSagaProperties props) {
        return new SmartLifecycle() {
            private volatile boolean running;

            @Override
            public void start() {
                factory.start();
                running = true;
                log.info("Temporal worker polling task queue '{}'", props.temporal().taskQueue());
            }

            @Override
            public void stop() {
                factory.shutdown();
                try {
                    factory.awaitTermination(10, TimeUnit.SECONDS);
                } catch (Exception e) {
                    log.warn("Worker did not stop cleanly: {}", e.getMessage());
                }
                running = false;
            }

            @Override
            public boolean isRunning() {
                return running;
            }
        };
    }
}
